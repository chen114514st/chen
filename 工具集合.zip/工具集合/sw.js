// ============================================================
// Service Worker · 工具箱合集
// ============================================================

var CACHE_NAME = 'toolbox-v1';
var urlsToCache = [
  '/hub.html',
  '/manifest.json',
  '/icon-512.png',
  '/mc/index.html',
  '/image/index.html',
  '/video/index.html',
  '/audio/index.html',
  '/text/index.html',
  '/dev/index.html',
  '/network/index.html',
  '/time/index.html',
  '/unit/index.html',
  '/games/index.html',
  '/tools/index.html',
  '/tools/qr/index.html',
  '/tools/apps/index.html',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css'
];

// 安装
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        return cache.addAll(urlsToCache);
      })
  );
});

// 拦截请求
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request)
      .then(function(response) {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});

// 激活
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
// ============================================================
// Service Worker · 离线缓存
// ============================================================

const CACHE_NAME = 'toolbox-v3';

// 需要缓存的文件列表
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',

  // ===== 核心工具箱 =====
  '/mc/index.html',
  '/mc/builder.html',
  '/mc/calculator.html',
  '/image/index.html',
  '/video/index.html',
  '/audio/index.html',
  '/text/index.html',
  '/dev/index.html',
  '/dev/calculator.html',
  '/network/index.html',
  '/time/index.html',
  '/unit/index.html',
  '/tools/index.html',
  '/games/index.html',
  '/website/index.html',
  '/website/more.html',

  // ===== 万能工具箱子页面 =====
  '/tools/qr/index.html',
  '/tools/danmaku/index.html',
  '/tools/clipboard/index.html',
  '/tools/diary/index.html',
  '/tools/express/index.html',
  '/tools/tomato/index.html',
  '/tools/remove-comments/index.html',
  '/tools/bmi/index.html',
  '/tools/tts/index.html',

  // ===== 游戏盒子子页面 =====
  '/games/muyu/index.html',
  '/games/crystal/index.html',
  '/games/qian/index.html',
  '/games/forest/index.html',
  '/games/cps/index.html',
  '/games/minesweeper/index.html',
  '/games/lucky/index.html',
  '/games/circle/index.html',
  '/games/needle/index.html',

  // ===== 样式 & 库 =====
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/gif.js/0.2.0/gif.js',
  'https://cdnjs.cloudflare.com/ajax/libs/gif.js/0.2.0/gif.worker.js'
];

// ============================================================
// 安装事件：缓存所有文件
// ============================================================
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('📦 缓存文件...');
        return cache.addAll(urlsToCache);
      })
      .then(function() {
        console.log('✅ 缓存完成');
        return self.skipWaiting();
      })
      .catch(function(err) {
        console.error('❌ 缓存失败:', err);
      })
  );
});

// ============================================================
// 激活事件：清理旧缓存
// ============================================================
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName !== CACHE_NAME) {
            console.log('🗑️ 删除旧缓存:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(function() {
      return self.clients.claim();
    })
  );
});

// ============================================================
// 请求拦截：缓存优先，网络回退
// ============================================================
self.addEventListener('fetch', function(event) {
  var request = event.request;

  // 跳过非 GET 请求
  if (request.method !== 'GET') {
    event.respondWith(fetch(request));
    return;
  }

  // 跳过 Chrome 扩展请求
  if (request.url.startsWith('chrome-extension://')) {
    event.respondWith(fetch(request));
    return;
  }

  event.respondWith(
    caches.match(request)
      .then(function(response) {
        // 缓存命中，返回缓存
        if (response) {
          return response;
        }

        // 缓存未命中，发起网络请求
        return fetch(request).then(function(networkResponse) {
          // 只缓存成功的响应
          if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
            return networkResponse;
          }

          // 克隆响应并存入缓存
          var responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME)
            .then(function(cache) {
              try {
                cache.put(request, responseToCache);
              } catch (e) {
                // 忽略缓存失败
              }
            });

          return networkResponse;
        }).catch(function() {
          // 网络请求也失败，返回离线页面（如果是HTML请求）
          if (request.headers.get('Accept') && request.headers.get('Accept').includes('text/html')) {
            return caches.match('/offline.html');
          }
          // 其他资源返回一个简单的响应
          return new Response('离线状态，请检查网络连接', {
            status: 503,
            statusText: 'Service Unavailable'
          });
        });
      })
  );
});